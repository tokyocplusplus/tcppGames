#ifndef OTHER
#define OTHER
#include <raylib.h>

// Define voxel structure
struct Voxel {
    Vector3 position;
    Color color;
};

// Define grid size
constexpr int GRID_SIZE = 20; 


#endif
