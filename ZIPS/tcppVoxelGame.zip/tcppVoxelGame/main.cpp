#include <raylib.h>
#include <rlgl.h>
#include <raymath.h>
#include <vector>
#include <iostream>
#include "other.h"

typedef uint16_t uint;

//------------------------------------------------------------------------------------
// Program main entry point
//------------------------------------------------------------------------------------
float crouchHeight = 1.0f; // Normal height
float standHeight = 2.0f;  // Height when standing

int main() {
    // Initialization
    const uint screenWidth = 1280;
    const uint screenHeight = 720;
    const uint ingameWidth = 256; 
    const uint ingameHeight = 144; 

    SetConfigFlags(FLAG_VSYNC_HINT);
    SetTargetFPS(60);
    InitWindow(screenWidth, screenHeight, "tcpp-VOXEL");

    RenderTexture2D lowres = LoadRenderTexture(ingameWidth, ingameHeight);

    Rectangle sourceRec = { 0.0f, 0.0f, static_cast<float>(lowres.texture.width), -static_cast<float>(lowres.texture.height) };
    Rectangle destRec = { 0, 0, static_cast<float>(screenWidth), static_cast<float>(screenHeight) };

    // Define the camera
    Camera3D camera = { 0 };
    camera.position = (Vector3){ 10.0f, 5.0f, 10.0f }; 
    camera.target = (Vector3){ 2.5f, 0.0f, 2.5f };      
    camera.up = (Vector3){ 0.0f, 1.0f, 0.0f };          
    camera.fovy = 90.0f;                                
    camera.projection = CAMERA_PERSPECTIVE;             

    ToggleFullscreen();
    DisableCursor();

    // Load shaders for CRT effect
    Shader shader = LoadShader("data/scan.vs", "data/scan.fs");
    Mesh cubeMesh = GenMeshCube(2.0f, 2.0f, 2.0f); 
    Material cubeMaterial = LoadMaterialDefault();
    cubeMaterial.maps[MATERIAL_MAP_DIFFUSE].color = PINK;
    Matrix cubeMatrix = MatrixTranslate(0.0f,0.0f,0.0f);
    
    rlEnableBackfaceCulling();

    // Main game loop
    while (!WindowShouldClose()) {
        // Update
        UpdateCamera(&camera, CAMERA_FIRST_PERSON);
        camera.position.y = IsKeyDown(KEY_LEFT_CONTROL) ? crouchHeight : standHeight;

        // Draw
        BeginTextureMode(lowres);
            ClearBackground(RAYWHITE);
            BeginMode3D(camera);
                DrawMesh(cubeMesh, cubeMaterial, cubeMatrix);
            EndMode3D();
        EndTextureMode();

        // Draw with CRT effect
        BeginDrawing();
            ClearBackground(RAYWHITE);
            BeginShaderMode(shader);
                DrawTexturePro(lowres.texture, sourceRec, destRec, (Vector2){ 0, 0 }, 0.0f, RAYWHITE);
            EndShaderMode();
            DrawFPS(10, 10);
        EndDrawing();
    }

    // De-Initialization
    UnloadShader(shader);               
    UnloadRenderTexture(lowres);        
    UnloadMesh(cubeMesh);               
    CloseWindow();                      

    return 0;
}
